import tkinter as tk
from src.gui.clock_canvas import AnalogClock

class ClockApp:
    def __init__(self, root):
        self.root = root
        self.root.title('Clock-py')
        
        # Create container frame
        self.frame = tk.Frame(root)
        self.frame.pack(expand=True, fill='both')
        
        # Create clock
        self.clock = AnalogClock(self.frame)
        
        # Add theme toggle button
        self.theme_btn = tk.Button(self.frame, text="Cambiar Tema", command=self.toggle_theme)
        self.theme_btn.pack(pady=5)
        
        # Track theme state
        self.is_dark = False
    
    def toggle_theme(self):
        self.is_dark = not self.is_dark
        if self.is_dark:
            self.frame.configure(bg='#2b2b2b')
            self.theme_btn.configure(bg='#404040', fg='white')
            self.clock.set_dark_theme()
        else:
            self.frame.configure(bg='white')
            self.theme_btn.configure(bg='SystemButtonFace', fg='black')
            self.clock.set_light_theme()

def main():
    root = tk.Tk()
    app = ClockApp(root)
    root.mainloop()

if __name__ == '__main__':
    main()