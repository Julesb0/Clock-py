import tkinter as tk
import math
import time
from src.models.linked_list import CircularDoublyLinkedList

class AnalogClock:
    def __init__(self, root):
        self.root = root
        self.canvas = tk.Canvas(root, width=400, height=400)
        self.canvas.pack()
        self.current_theme = {
            'hour_hand': 'black',
            'min_hand': 'blue',
            'sec_hand': 'red',
            'center': 'black'
        }
        
        # Inicializar con la hora actual
        now = time.localtime()
        self.ticks = CircularDoublyLinkedList.build_ticks(60)
        
        # Configurar nodos con la hora actual
        self.sec_node = self.ticks.get_node_at(now.tm_sec)
        self.min_node = self.ticks.get_node_at(now.tm_min)
        # Calcular posición de hora (cada hora = 5 ticks)
        hour_pos = (now.tm_hour % 12) * 5 + (now.tm_min // 12)
        self.hour_node = self.ticks.get_node_at(hour_pos)
        
        self.center = (200, 200)
        self.R = 100
        self.canvas.pack()
        self.draw_static()
        self.update_clock()

    def draw_static(self):
        # Dibujar la esfera del reloj
        cx, cy = self.center
        self.canvas.create_oval(
            cx-self.R, cy-self.R, 
            cx+self.R, cy+self.R,
            width=2
        )
        
        # Dibujar marcadores de hora
        for i in range(12):
            angle = math.radians(i * 30 - 90)
            start = (
                cx + (self.R-10) * math.cos(angle),
                cy + (self.R-10) * math.sin(angle)
            )
            end = (
                cx + self.R * math.cos(angle),
                cy + self.R * math.sin(angle)
            )
            self.canvas.create_line(
                start[0], start[1],
                end[0], end[1],
                width=2
            )

    def update_clock(self):
        # Borrar SOLO las manecillas anteriores usando el tag 'hands'
        self.canvas.delete('hands')

        # Obtener posiciones actuales
        sec_deg = self.sec_node.data['deg']
        min_deg = self.min_node.data['deg'] + (self.sec_node.data['index'] / 60) * 6
        hour_deg = self.hour_node.data['deg'] + (self.min_node.data['index'] / 60) * 30

        # Dibujar manecillas con el tag 'hands' para poder borrarlas después
        self.draw_hand(hour_deg, self.R*0.5, 6, self.current_theme['hour_hand'], 'hands')
        self.draw_hand(min_deg, self.R*0.7, 4, self.current_theme['min_hand'], 'hands')
        self.draw_hand(sec_deg, self.R*0.9, 2, self.current_theme['sec_hand'], 'hands')

        # Centro del reloj
        cx, cy = self.center
        self.canvas.create_oval(
            cx-6, cy-6, cx+6, cy+6,
            fill=self.current_theme['center'],
            tags='hands'
        )

        # Avanzar los nodos
        self.sec_node = self.sec_node.next
        if self.sec_node.data['index'] == 0:
            self.min_node = self.min_node.next
            if self.min_node.data['index'] == 0:
                self.hour_node = self.hour_node.next

        # Programar siguiente actualización
        self.root.after(1000, self.update_clock)

    def draw_hand(self, angle_deg, length, width, color, tag='hands'):
        cx, cy = self.center
        angle = math.radians(angle_deg - 90)
        x = cx + math.cos(angle) * length
        y = cy + math.sin(angle) * length
        return self.canvas.create_line(
            cx, cy, x, y,
            width=width,
            fill=color,
            capstyle='round',
            tags=tag
        )